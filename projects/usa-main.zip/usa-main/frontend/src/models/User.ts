export interface IUser {
    username: string;
    isActivated: string;
    id: string;
}