tinyMCE.addI18n("fr.grappelli",{
grappelli_adv_desc:"Basculer le menu avancé",
grappelli_documentstructure_desc:"Basculé la structure de document",
});
